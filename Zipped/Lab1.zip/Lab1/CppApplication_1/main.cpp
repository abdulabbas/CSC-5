/* 
 * File:   main.cpp
 * Author: Abdul Hakim Abbas
 * Purpose: Frist Progam to test the IDE
 *
 * Created on June 22, 2015, 12:35 PM
 */

//System Libraries
#include <iostream>  //File I/O
using namespace std; //std namespace -> iostream

//User Libraries

//Global constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables Here
    
    //Input Values Here
    
    //Process Input Here
    
    //Output Unknowns Here
    cout<<"Hello World"<<endl;
    //Exit Stage Right!
    return 0;
}

