/* 
 * File:   main.cpp
 * Author: Abdul-Hakim
 * Purpose: Template for other works 2nd version 
 * Created on July 14, 2015, 6:24 PM
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
int example(int,int&);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Initialize and Prompt for inputs
    
    //Process the inputs
    
    //Output the results

    //Exit Stage Right
    return 0;
}

/**************************************************
 *             Example Function                   *
 **************************************************
 * Purpose:  Show how to comment a function
 * Input:
 *    a-> Example input pass by value
 * Input-Output:
 *    b-> Example input-output pass by reference
 * Output:
 *    c-> Example return
 */
int example(int a,int &b){
    //Declare a variable c
    int c;
    //Process
    
    //Output
    return c;
}

