/* 
 * File:   main.cpp
 * Author: Abdul-Hakim
 *
 * Created on July 14, 2015, 12:20 PM
 */

//System Libraries
#include <cstdlib>
#include <iostream>
#include <ctime>
using namespace std;


//User Libraries
//Global Constants
//Function prototypes
//Execution Begins Here!
int main(int argc, char** argv) {
//Declare variables

//Initialize and prompt for inputs
    
//Process Inputs
    
//Output results

//Exit stage right    
    return 0;
}
//External Functions if needed

